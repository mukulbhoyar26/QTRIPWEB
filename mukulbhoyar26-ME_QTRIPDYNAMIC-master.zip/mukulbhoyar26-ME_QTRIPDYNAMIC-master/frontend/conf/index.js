
const config = { backendEndpoint: "http://3.111.244.21:8082" };


export default config;

  
